const Discord = require("discord.js");

 exports.run = (client, message, args) => {

   let embed = new Discord.RichEmbed()
    .setColor('RANDOM')
    .setFooter("iHelp Bot | Made by iHelp Executives")
    .setTitle('Purge warn')
    .addField('There will be a purge in 10 seconds say `cancel` to cancel this act')
  message.author.send(embed)
  message.delete().catch();
}