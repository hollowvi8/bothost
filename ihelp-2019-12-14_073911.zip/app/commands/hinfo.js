const Discord = require("discord.js");

 exports.run = (client, message, args) => {

   let embed = new Discord.RichEmbed()
    .setColor('RANDOM')
    .setTitle('Help Info Commands')  
    .setFooter("iHelp Bot | Made by iHelp Executives")
    .addField("`.update`", "Sends a update message")
    .addField("`.bug`", "Sends a bug!")
    .addField("`.broke`", "Shows that we know its broke and were fixing")
    .addField("`.about-us`", "Shows info about us.")
    .addField("`.bot`", "Bot Info")
    .addField("`.apply`", "Apply Info")
   .addField("`.loader`", "Loader Info")
   .addField("`.news`", "Shows the current iHelp News")
   .addField("`.modlist`", "Shows online Moderators")
   .addField("`.serverinfo`", "Shows Server Info")
   .addField("`.setstatus`", "Sets Bot Status")
  .addField("`.userinfo`", "Gives User Info") 
   .addField("`.vote`", "Creates a vote")
   .addField("`.rules`", "Sends the rules")
   .addField("`.status`", "Shows the Bot Status")
   .addField("`.uptime`", "Shows the Bots Uptime")
message.delete().catch();
message.channel.send(embed);
}