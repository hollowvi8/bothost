const Discord = require("discord.js");

 exports.run = (client, message, args) => {

   let embed = new Discord.RichEmbed()
    .setColor('RANDOM')
    .setTitle('Music Commands')  
    .setFooter("iHelp Music | Coded By UhTrue#4919")
    .addField("`.play [SONGHERE]`", "Plays a song in a voice channel")
    .addField("`.skip`", "Skips the current song")
    .addField("`.stop`", "Stops the current song")
    .addField("`.volume`", "Sets the volume")
    .addField("`.np`", "Shows Current song playing")
    .addField("`.queue`", "Shows all songs in the queue")
    .addField("`.pause`", "Pauses The current song")
    .addField("`.resume`", "Resumes the current song")
message.delete().catch();
message.channel.send(embed);
}