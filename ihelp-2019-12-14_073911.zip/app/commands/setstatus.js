exports.run = (client, message, args) => {
 if(message.author.id !== '522974103435739142'  && message.author.id !== '522974103435739142') return
  if(!args[0]) return;
  if(args[0] === 'game') return message.reply('Please tell me something to watch!');
  args = args.join(" ");
  message.reply(`I am now watching \`${args}\`.`);
  client.user.setActivity(`${args}`, {type: "watching"});
};
