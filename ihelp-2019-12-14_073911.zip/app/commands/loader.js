const Discord = require("discord.js")
module.exports.run = async (client, message, args) => {
   var embed = new Discord.RichEmbed()
  await embed.setColor('PURPLE')
 .setAuthor(client.user.username, client.user.avatarURL)
  .setThumbnail(client.user.avatarURL)
  .setFooter('iHelp Bot | Made by the iHelp Owners')
  .setTitle('LOADER')
  await embed.setDescription(`

BETA: COMING SOON


`)
  
  
  message.channel.send(embed)
}
