const Discord = require("discord.js");

 exports.run = (client, message, args) => {

   let embed = new Discord.RichEmbed()
    .setColor('RANDOM')
    .setTitle('Moderation Commands')  
    .setFooter("iHelp Moderation | By iHelp Owners")
    .addField("`.kick`", "Kicks a player")
    .addField("`.mute`", "Mutes a player")
    .addField("`.unmute`", "Unmutes a player")
    .addField("`.ban`", "Sets the volume")
    .addField("`.unban`", "Shows Current song playing")
    .addField("`.purge`", "Deletes a message")
    .addField("`.restart`", "Restarts the bot")
    .addField("`.reload`", "Reload a command")
   .addField("`Coming Soon`", "COMING SOON")
   .addField("`Coming SOON`", "Yay")
message.delete().catch();
message.channel.send(embed);
}