const Discord = require("discord.js");

 exports.run = (client, message, args) => {

   let embed = new Discord.RichEmbed()
    .setColor('PURPLE')
    .setTitle('How to start the bots back up')  
    .setFooter("iHelp Bot | Made by iHelp")
    .addField("`MAIN`", "Now Hosted Private")
    .addField("`MUSIC`", "https://uhtrue-ihelp-music.glitch.me")
   .addField("**INVITE INFO**", "https://discordbots.org/bot/478912375681056820")
message.delete().catch();
message.channel.send(embed);
}