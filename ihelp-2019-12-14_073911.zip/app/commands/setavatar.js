const Discord = require("discord.js")
exports.run = (client, message, args) => {
if (message.author.id === '272501224002158603' && message.author.id !== '168766548725596160') {
  const sayMessage = args.join(" ");
  client.user.setAvatar(sayMessage);
  }
else {
  message.channel.send('❌ Error: Sorry, you do not have the correct Permissions Owner. If you think that this is an issue please contact one of the Founders.')
  return;
  }
}
