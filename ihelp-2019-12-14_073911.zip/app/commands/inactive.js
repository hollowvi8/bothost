const Discord = require('discord.js');
module.exports.run = async (bot, message, args) => {
  
  
  
  let kReason = args.join(" ").slice(22);
  if(!kReason) return message.channel.send("Please provide a reason!")

  let kickEmbed = new Discord.RichEmbed()
  .setDescription("Inactive Notice")
  .setColor("#f45642")
  .addField("Name", `${message.author}`)
  .addField("Reason", `${kReason ? kReason : "None."}`)
  .setTimestamp();

  let kickChannel = message.guild.channels.find(`name`, 'inactvity-notice');
  if(!kickChannel) return message.channel.send("**Can't find `inactivity-notice` channel.**");
   let embed = new Discord.RichEmbed()
  .setDescription("Inactive Notice")
  .setColor("#f45642")
  
  .addField("Name", message.author.tag)
  .addField("Time", message.createdAt.toLocaleString())
  .addField("Reason", `${kReason ? kReason : "None."}`);
kickChannel.send(kickEmbed);


}