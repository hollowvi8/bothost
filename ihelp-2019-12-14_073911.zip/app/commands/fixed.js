const Discord = require('discord.js');//DO NOT TOUCH

exports.run = async(bot, message, args) =>{
  let embed = new Discord.RichEmbed()
  .setTitle("ISSUES")
  .setDescription("ONLY DEVELOPERS MAY EXECUTE THIS COMMAND.")
  .setColor("#cdf785");
  if(message.author.id !== '272501224002158603' && message.author.id !== '269832519577239552' && message.author.id !== '522974103435739141') return message.channel.send(embed);
  
message.channel.send(`The **Issue** has been fixed!`).then(() =>{
process.exit(1);
})
}