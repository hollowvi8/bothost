const Discord = require("discord.js")
module.exports.run = async (client, message, args) => {
   var embed = new Discord.RichEmbed()
  await embed.setColor('PURPLE')
 .setAuthor(client.user.username, client.user.avatarURL)
  .setThumbnail(client.user.avatarURL)
  .setTitle('iHelp News')
  await embed.setDescription(`News: 
- **March Break**
@UhTrue#4919 Will be going home when they get home
they will be uploading the Old Loader like many
of you would like then we will be adding more features
and fix our games and get new ones!


- **INTERVIEW CENTER**
Most of you know this but some don't the Interview Center is currently
Broken «SOME PLAYERS CANT JOIN»
THIS ISSUE WILL BE FIXED SOMETIME SUNDAY
  
- **LOADER**
New Loader coming soon! Old loader being uploaded Sunday!

- **Music Commands**
We have made some music commands
COMMANDS **.play  .skip  .stop  .volume
  .np  .queue  .pause  .resume**
Music Commands Can Also Be Found By Saying
**.musichelp**

**iHelp Bot 3 Rules**
1. This is not a bot to speak through
2. No using this bot to troll or annoy staff
3. Respect N0lxn and UhTrue's Creation OR ELSE`)
  
  
  message.channel.send(embed)
}