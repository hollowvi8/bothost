const Discord = require ("discord.js")
module.exports.run = async (client, message, args) => {
  var embed = new Discord.RichEmbed()
  await embed.setColor('RED')
  .setAuthor(client.user.username, client.user.avatarURL)
  .setThumbnail('https://i.postimg.cc/prvV5ynd/baseline_check_circle_white_18dp.png')
  .setTitle (':white_check_mark: Client responding normally')
  await embed.setDescription('There are Some issues in bot hosting and/or bot code.\nTo view a list of commands, run .help')
  message.channel.send(embed)
  
  const msg = await message.channel.send("Pinging...");
  var embed = new Discord.RichEmbed()
  .setAuthor(message.author.username, message.author.avatarURL)
  .setDescription(`:ping_pong: Pong! Latency is ${msg.createdTimestamp - message.createdTimestamp}ms. API Latency is ${Math.round(client.ping)}ms`)
  .setColor('RANDOM')
  message.channel.send(embed);
};
