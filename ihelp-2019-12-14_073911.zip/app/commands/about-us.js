const Discord = require("discord.js")
module.exports.run = async (client, message, args) => {
   var embed = new Discord.RichEmbed()
  await embed.setColor('GOLD')
 .setAuthor(client.user.username, client.user.avatarURL)
  .setThumbnail(client.user.avatarURL)
  .setTitle('iHelp About-Us')
  .addField(`Website`, '[Website](BROKEN)',true)
  await embed.setDescription(`About iHelp: 

- Founded by: UhTrue

- What is iHelp?: It is a anti-exploit service that will continue to strive to keep the games safe.

- Why us?: You should choose us because everyday we are advancing in our loader. We also do not have staff the abuse, if we do then we sct on it.

- Administration: Founder: UhTrue \nCo-Founders: 19jbiondani, Deputy_Cameron, RunningHorses13`)
  message.channel.send(embed)
}
