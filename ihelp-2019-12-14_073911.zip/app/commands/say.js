const Discord = require("discord.js");
 exports.run = async (bot, message, args) => {
   
   const sayMessage = args.join(" ");
      message.delete().catch();
      message.channel.send(sayMessage);
}