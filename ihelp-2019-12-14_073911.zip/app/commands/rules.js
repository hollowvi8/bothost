const Discord = require("discord.js")
module.exports.run = async (client, message, args) => {
   var embed = new Discord.RichEmbed()
  await embed.setColor('GOLD')
 .setAuthor(client.user.username, client.user.avatarURL)
  .setThumbnail(client.user.avatarURL)
  .setTitle('iHelp Rules')
  await embed.setDescription(`Rules: 

**RULES**
**RULES CHANGE OFTEN**

1.  Don't be a Disrespectful Person.
2. Don't Abuse anything.
3. Don't post any Swear Or Cuss Words
4. Do Not Abuse Profanity.
5. Do Not Spam Pornographic Pictures No Matter What!
6. Don't Spam in discord or in-game.
7. Don't Free Rank.
8. Don't Abuse the Shout.
9. Don't abuse the Group Wall.
10. Don't break the game.
11. Don't  Abuse your Power whether it may be Admin or of rank.
12. Don't be Power Hungry.
13. You Must Follow ALL of our rules.
14. You Must Screenshot ALL Abuse
15. You Must Screenshot ALL Exploits
16. You Must Be In A Text Channel During An Meeting
17. No Racism
18. No dating in-game. (Keep it in PM's)
19. No dating in-discord. (Keep it in DM's)
20. Do Not act Un-Proffessional.
21. Do Not Ear Rape on Voice Channels.
22. Do not advertise anything unless you have permission.
23. Being in Mac’s server Or Any Of Pupper’s Servers is a instant ban.
24. F u z z. Is banned from All iHelp Servers!
25. Tagging a President + with DONT TAG in there name will be warned 2 times, then kicked.
26. Do Not Ban @RunningHorses13 | Guest [AFK]
27. @Jam_Escobar | Guest Is Banned From All IHelp Servers
28. Do Not Talk About Momo Rule By <@!269832519577239552> - DONT TAG
29. No spoilers (black text) as it overrides filters.`)
message.delete().catch();
message.channel.send(embed);

}
