const Discord = require("discord.js");

 exports.run = (client, message, args) => {

   let embed = new Discord.RichEmbed()
    .setColor('RANDOM')
    .setTitle('Help FUN Commands')  
    .setFooter("iHelp Bot | Made by iHelp Executives")
    .addField("`.8ball`", "FUN 8ball commands")
    .addField("`.joke`", "Get a joke!")
    .addField("`.math`", "Solve a problem")
    .addField("`.flip`", "FLIPS your text.")
    .addField("`.help`", "Back to origanal help")
   .addField("`.say`", "Repeats Your Message")
   .addField("`.weather`", "Gives the Weather")
   .addField("`.timer`", "Sets a timer")
   .addField("`COMING SOON`", ":)")
message.delete().catch();
message.channel.send(embed);
}