const Discord = require("discord.js")
exports.run = (client, message, args) => {

let sender = message.author;
let allowedRole = message.guild.roles.find("name", "everyone");
let sendchannel = message.channel;
let RE = message.RichEmbed
let user = message.mentions.members.first();
       if (!message.member.hasPermission("MANAGE_MESSAGES")) return message.channel.send("Error: Manage_Messages is required to use this command")

        const sayMessage = args.join(" ");
    // Then we delete the command message (sneaky, right?). The catch just ignores the error with a cute smiley thing.
    message.delete().catch(O_o=>{}); 
    // And we get the bot to say the thing: 

          let embedsay = new Discord.RichEmbed()
      .setColor('#2dce38')
      .setAuthor('iHelp Update', 'https://cdn.glitch.com/5dd2251e-c967-4a54-98e1-223cd721b2ae%2FUpdate.jpg?1550964206516')
      .setDescription(`${sayMessage}`)
      .setTimestamp();
  message.channel.send(embedsay);



       let reason = args.slice(0).join(" ");
       let staffc = message.guild.channels.find("name", "mod-log")
        
        if (!staffc) 
            return message.reply('I cannot find a logs channel');

        if (reason.length < 1) 
            return message.reply('You must supply something to say.');


        const embed = new Discord.RichEmbed()
            .setColor(0x8cff00)
            .setDescription(`**Action:** Say\n**User:** ${message.author.tag}\n**They said:** ${reason}\n**In Channel:** ${sendchannel}`)
            .setTimestamp();
        staffc.send({embed});

        
        
}
