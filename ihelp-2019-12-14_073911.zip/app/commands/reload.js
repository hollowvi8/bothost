exports.run = async (client, message, args, level) => { // eslint-disable-line no-unused-vars


if (message.author.id !== "272501224002158603" && message.author.id !== "269832519577239552" && message.author.id !== "522974103435739142") return message.channel.send("⛔ **ACCESS DENIED**");

    try {
        delete require.cache[require.resolve(`./${args[0]}.js`)];
    } catch (e) {

        return message.channel.send(`Unable to reload: ${args[0]}.js`);
    }

    message.channel.send(`**Successfully reloaded:** ${args[0]}.js`);


}