const Discord = require("discord.js");

 exports.run = (client, message, args) => {

   let embed = new Discord.RichEmbed()
    .setColor('RANDOM')
    .setTitle('Help command')  
    .setFooter("iHelp Bot | Made by iHelp Executives")
    .addField("`.hmusic`", "Music Commands")
    .addField("`.hinfo`", "Info Commands")
    .addField("`.hmod`", "Mod Commands")
    .addField("`.hfun`", "Fun Commands")
message.delete().catch();
message.channel.send(embed);
}