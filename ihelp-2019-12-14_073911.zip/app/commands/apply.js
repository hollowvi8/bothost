const Discord = require("discord.js")
module.exports.run = async (client, message, args) => {
   var embed = new Discord.RichEmbed()
  await embed.setColor('RANDOM')
 .setAuthor(client.user.username, client.user.avatarURL)
  .setThumbnail(client.user.avatarURL)
  .setTitle('iHelp Application')
  .addField(`Application Game ♥`, 'Coming Soon',true)
  message.author.send(embed)
  message.delete().catch();
}