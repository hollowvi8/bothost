------
iHelp
-----
*Coded by UhTrue#4919 and N0lxn#8383